package chess;

/**
 * Color of the chess pieces. A chess piece can be either black or white.
 */
public enum Color {
  BLACK, WHITE
}
