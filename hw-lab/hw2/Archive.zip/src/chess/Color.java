package chess;

/**
 * This is a ENUM class that have black and white chess piece colors.
 */
public enum Color {
  BLACK,
  WHITE
}
