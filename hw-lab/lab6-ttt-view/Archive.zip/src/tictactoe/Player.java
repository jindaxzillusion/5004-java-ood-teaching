package tictactoe;

/**
 * This is a ENUM class that have X and O for tic-tac-toe player.
 */
public enum Player {
  X,
  O
}
