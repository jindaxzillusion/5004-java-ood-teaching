package soccer;

/**
 * This is a ENUM class that have GOALIE, DEFENDER, MIDFIELDER,
 * FORWARD, for soccer player.
 */
public enum Position {
  GOALIE,
  DEFENDER,
  MIDFIELDER,
  FORWARD,
}
