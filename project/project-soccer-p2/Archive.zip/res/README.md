# Overview
- The Soccer Project is a Java program that provides functionality for managing soccer players and their information, such as their first name, last name, date of birth, preferred position, skill level, and jersey number. U10 soccer teams have seven players on the field. The best players are usually selected as the starting lineup and the remaining players are on the bench, ready to substitute the players on the field.

# Features
- The user (coach) can add players into the system as candidates for the team
- The user can be notified if a player is not allowed (because it is 10 years of age or older)
- The user can be able to click a button to create the team
- The user can be notified if there are not enough players to create a team
- The user can be able to get a list of all the team players (just as it is produced by your model)
- The user can be able to get a list of the starting lineup (just as it is produced by your model)


# How To Run
- To run the program, you need to have Java installed on your computer. You can download Java from https://www.java.com/en/download/.

- Once Java is installed, you can run the program using the project-soccer.jar file in src folder.
- An alternative way is to navigate to src directory, and open a terminal using the following command:

java -jar project-soccer.jar

# How to Use the Program
- Input Player Data: fill out the form with the player's information, Click on the "Add Player" button
- View All Players: Once you have at least 10 players in your team, click on the "Get All Players" button to view all players on the team.
- View Starting Line-up: Click on the "Get Starting Line Up" button to view all players on the team.

# Design/Model Changes
- Add "startingLineup.clear()" in model setStartingLineup method so that starting lineup will always be 7 people
- Handle bad input such as skill level < 1 or > 5.

# Assumptions
- Skill level of a player will be represented as an integer value, where higher value represents higher skill level.
- Player preferred position is not guaranteed when selecting starting lineup.
- Starting Lineup are selected by high skill level.

# Limitations
- Not handling first name / last name duplication problem, player with same first name, last name are considered as different player.
- User should enter correct input for skill level (0 - 5)
- User should enter number input for Position: Enter player preferred position (1-4): 1 - GOALIE, 2 - DEFENDER, 3 - MIDFIELDER, 4 - FORWARD 

# Citations
- “A visual guide to swing components,” A Visual Guide to Swing Components (from: The Java™ Tutorials &gt; Graphical User Interfaces &gt; Swing Features). [Online]. Available: https://web.mit.edu/6.005/www/sp14/psets/ps4/java-6-tutorial/components.html. [Accessed: 15-Apr-2023].
- “A visual guide to layout managers,” A Visual Guide to Layout Managers (The Java™ Tutorials &gt; Creating a GUI With Swing &gt; Laying Out Components Within a Container). [Online]. Available: https://docs.oracle.com/javase/tutorial/uiswing/layout/visual.html. [Accessed: 15-Apr-2023].
- “Learn java with swing online class: LinkedIn Learning, formerly Lynda.com,” LinkedIn. [Online]. Available: https://www.linkedin.com/learning/learn-java-with-swing. [Accessed: 15-Apr-2023]. 